#!/bin/sh

func() {
    echo "The script created by Jiaxuan Wang 20210712"
    echo "Usage:"
    echo "[-h]: The help document:"
    echo -e "[-i]: The script only support a file input ,\nthe file can be fastq or fasta"
    exit -1
}
input=$1
while getopts "i:h" opt; do
    case $opt in
      i) input="$OPTARG";;
      h) func;;
      ?) func;;
    esac
done

#==============================================
# if first analysis need check the genome index
#==============================================

wkdir ${input} | awk -v OFS="\t" '{print "'${input}'\t"$1,$2,$3"("$3/$2*100"%)",$4"("$4/$2*100"%)",$5"("$5/$2*100"%)"}'
