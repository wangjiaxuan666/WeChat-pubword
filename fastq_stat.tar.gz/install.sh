#!/bin/sh
gcc -o fastq_stat parse.c -lz
dir=`pwd`
wkdir=`ls fastq_stat|sed "s:^:${dir}\/:"`
sed "s;wkdir;$wkdir;" fq_stat.sh > fastq_stat.sh
rm fq_stat.sh
